package HomeWork;

public interface Shape {
    abstract double area();//面积
    abstract  double girth();//周长
}
